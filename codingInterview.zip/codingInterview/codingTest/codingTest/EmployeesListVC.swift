//
//  EmployeesListVC.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//

import UIKit
import CoreData
class EmployeesListVC: UIViewController {

    var viewModel = EmployeeListViewModel()
    var employees = [Employee]()
   
    
    @IBOutlet weak var employeeTableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getEmployeeList()
    }

    func getEmployeeList() {
        
        let data = viewModel.fetchRecordsForEntity("Employee", inManagedObjectContext: PersistanceService.context)

        if data.count == 0 {
        
        getEmployees()
        
        } else {
       
        self.employees = data as! [Employee]
        self.employees = self.employees.sorted(by: { $0.id < $1.id })
        
            DispatchQueue.main.async {
                self.employeeTableView.reloadData()
            }
        }
    }


func getEmployees() {
    
    WebServices().GetAPI(urlString: "http://www.mocky.io/v2/5d565297300000680030a986") { (result : Result<[DataModel],Error>) in
        switch result {
        case .success(let result):
            self.saveToCoreData(result)
        case .failure(let failure):
            print("error",failure)
        }
    }
    }
    
    func saveToCoreData(_ data: [DataModel]) {
        data.map {
            let employee = Employee(context: PersistanceService.context)
            employee.id = Int64($0.id!)
            employee.username = $0.username
            employee.email = $0.email
            employee.name = $0.name
            employee.profile_image = $0.profile_image
            let address = Address(context: PersistanceService.context)
            address.suite = $0.address?.suite
            address.city = $0.address?.city
            address.street = $0.address?.street
            address.zipcode = $0.address?.zipcode
            employee.address = address
            let company = Company(context: PersistanceService.context)
            company.name = $0.company?.name
            company.bs = $0.company?.bs
            company.catchPhrase = $0.company?.catchPhrase
            employee.company = company
        }
        PersistanceService.saveContext()
        
        getEmployeeList()
    }
}

extension EmployeesListVC: UITableViewDelegate, UITableViewDataSource{
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return employees.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeCell", for: indexPath) as! EmployeeCell
        cell.selectionStyle = .none
        let employee = employees[indexPath.row]
        cell.nameLabel.text = employee.name
        cell.companyNameLabel.text = employee.company?.name ?? "Company"
        cell.profileImage.loadImageFromUrlString(employee.profile_image ?? "")
        
        return cell
    }
    
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 84
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let StoryBoard = UIStoryboard.init(name: "Main", bundle: nil)
        let VC = StoryBoard.instantiateViewController(withIdentifier: "EmployeeDetailsVC") as! EmployeeDetailsVC
        VC.employee = employees[indexPath.row]
        self.navigationController?.pushViewController(VC, animated: true)
    }
}

let imageCache = NSCache<NSString, UIImage>()

extension UIImageView {
    
    func loadImageFromUrlString(_ urlString: String) {
        
        guard let url = URL(string: urlString) else {
            self.image = UIImage(systemName: "person")
            return
        }
    
        if let cachedImage = imageCache.object(forKey: urlString as NSString){
            self.image = cachedImage
            return
        }
        URLSession.shared.dataTask(with: url, completionHandler: { (data, response, error) in
            
            if error != nil {
                return
            }
            
            DispatchQueue.main.async {
                
                if let imageToCache = UIImage(data: data!) {
                    imageCache.setObject(imageToCache, forKey: urlString as NSString)
                    self.image = imageToCache
                }
            }
        }).resume()
    }
}
