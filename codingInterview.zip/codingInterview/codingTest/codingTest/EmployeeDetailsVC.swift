//
//  EmployeeDetailsVC.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//

import Foundation
import UIKit

class EmployeeDetailsVC: UIViewController {
    
    var employee: Employee?
    
    var itemDataSource = ["Name", "User Name", "Email address", "Address", "Phone",
                          "Website", "Company Details"]
    
    @IBOutlet weak var detailsTable: UITableView!
    
    @IBOutlet weak var profileImage: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        populateData()
    }
    
    func populateData() {
        
        DispatchQueue.main.async {
            self.profileImage.loadImageFromUrlString(self.employee?.profile_image ?? "")
            self.detailsTable.reloadData()
        }
    }

func getValueForIndex(_ index: Int) -> String{
    
    switch index {
    case 0:
        return employee?.name ?? ""
    case 1:
        return employee?.username ?? ""
    case 2:
        return employee?.email ?? ""
    case 3:
        return getAddress()
    case 4:
        return employee?.phone ?? ""
    case 5:
        return employee?.website ?? ""
    case 6:
        return employee?.company?.name ?? ""
    default:
        return ""
    }
}
    
    func getAddress() -> String {
        
        let suite = employee?.address?.suite ?? ""
        let street = employee?.address?.street ?? ""
        let city = employee?.address?.city ?? ""
        let zip = employee?.address?.zipcode ?? ""
        return suite + ", " + street + ", " + city + ", " + zip
    }
}
extension EmployeeDetailsVC: UITableViewDelegate, UITableViewDataSource{
    
    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return 7
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "EmployeeDetailCell", for: indexPath) as! EmployeeDetailCell
        cell.selectionStyle = .none
        
        cell.itemLabel.text =  "\(itemDataSource[indexPath.row]): \(getValueForIndex(indexPath.row))"
        
        return cell
    }
}
