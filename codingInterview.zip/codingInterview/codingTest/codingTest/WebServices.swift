//
//  WebServices.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//

import Foundation

class WebServices {

func GetAPI<T : Decodable>(urlString : String ,completion : @escaping(Result<T,Error>) -> () ) {
    guard let url = URL(string: urlString) else { return }
    URLSession.shared.dataTask(with: url) { data, response, error in
        if let error = error {
        print("error",error)
        }
        guard let data = data else { return }
        
        do {
            let modeldata = try JSONDecoder().decode(T.self, from: data)
            completion(.success(modeldata))
        } catch let err {
         print("error")
        completion(.failure(err))
            
        }

    }.resume()
}
}
