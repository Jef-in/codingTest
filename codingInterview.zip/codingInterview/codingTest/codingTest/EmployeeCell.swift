//
//  EmployeeCell.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//

import Foundation
import UIKit

class EmployeeCell: UITableViewCell {
    
    @IBOutlet weak var profileImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var companyNameLabel: UILabel!
    
}
