//
//  EmployeeDetailCell.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//

import Foundation
import UIKit

class EmployeeDetailCell: UITableViewCell {
    
    @IBOutlet weak var itemLabel: UILabel!
    
}
