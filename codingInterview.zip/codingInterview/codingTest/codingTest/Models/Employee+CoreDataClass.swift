//
//  Employee+CoreDataClass.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//
//

import Foundation
import CoreData

@objc(Employee)
public class Employee: NSManagedObject {

}
