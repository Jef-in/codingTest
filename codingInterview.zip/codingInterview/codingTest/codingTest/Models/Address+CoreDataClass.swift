//
//  Address+CoreDataClass.swift
//  codingTest
//
//  Created by Jefin on 19/02/22.
//
//

import Foundation
import CoreData

@objc(Address)
public class Address: NSManagedObject {

}
